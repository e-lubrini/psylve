<h1 align="center">Pipeline Evaluation</h1>


#### [◄ Back to main README](https://github.com/e-lubrini/PsylVe/blob/main/README.md)
